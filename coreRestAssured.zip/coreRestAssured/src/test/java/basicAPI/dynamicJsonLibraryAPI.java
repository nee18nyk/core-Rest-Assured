package basicAPI;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.*;
import static org.junit.Assert.assertNotNull;
//To build the project in Junit Right-click on project, go to Properties > Java Build Path. 
//Check under the Libraries tab junit is added. Annotations added in the script make it junit test
//pre requisite is pom xml should have all junit dependancies
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import files.payload;

public class dynamicJsonLibraryAPI {

	public void addBook(String isbn, String aisle){
		RestAssured.baseURI = "http://216.10.245.166";
	//post request to add multiple books in the library
		String postresponse = given().log().all().header("Content-Type","application/json")
		.body(payload.AddBook(isbn,aisle))
		.when().post("/Library/Addbook.php").then().assertThat().statusCode(200)
		.header("Server","Apache").extract().response().asString();
		System.out.println("Posted request is: " +postresponse);

	JsonPath js3 = new JsonPath(postresponse);
	String id = js3.getString("ID");
	System.out.println(id);
	
	//get request to retrieve the added multiple books from the library
	String getResponse = given().log().all().queryParam("ID", id).when().get("/Library/GetBook.php")
	.then().assertThat().log().all().statusCode(200).header("Server","Apache").extract().response().asString();
	System.out.println("Retrieved response is: " +getResponse);
	}
	@ParameterizedTest
	//ensure to fully change data in order to get success response,
	//tweaking a few chars in below data sometimes doesn't return success
	@CsvSource({
			"fre,018",
			"cyu,01",
			"tne,021"
	})
	public void testWithCsvSource(String isbn, String aisle) {
		addBook(isbn, aisle);
		assertNotNull(isbn);
		assertNotNull(aisle);
	}
	//next assignment: delete operation to delete the above added books from the library
}
