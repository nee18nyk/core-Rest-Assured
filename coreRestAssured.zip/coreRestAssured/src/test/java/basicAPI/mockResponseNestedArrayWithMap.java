package basicAPI;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

import files.payloadone;
import io.restassured.path.json.JsonPath;

public class mockResponseNestedArrayWithMap {
	
	@Test
	public void Jsonvalidations() {
	JsonPath js = new JsonPath(payloadone.CourseDetailsNestedArray());

	// Fetch the categories within the 'courses' node
    Map<String, List<Map<String, Object>>> courses = js.getMap("courses");
    int categorySumPrice = 0;
    // keyset returns a set view of the keys contained in the map, allowing iteration over map's keys
    for (String category : courses.keySet()) {
        // Fetch all courses within the category
        List<Map<String, Object>> courseList = courses.get(category);
        System.out.println("Category: " +category);
        int sumPrice = 0;
        for (Map<String, Object> course : courseList) {
            String title = course.get("courseTitle").toString();
            String price = course.get("price").toString();
            System.out.println("Title: " +title + ", Price: " +price);
            sumPrice += Integer.parseInt(price);
        }
        System.out.println("Total price per category: " +sumPrice);
        categorySumPrice += sumPrice;
    }
    System.out.println("Total price of all categories: " +categorySumPrice);
}
}
