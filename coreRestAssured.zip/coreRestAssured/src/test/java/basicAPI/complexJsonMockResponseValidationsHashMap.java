package basicAPI;

import java.util.HashMap;
import java.util.List;

import org.junit.jupiter.api.Test;

import files.payload;
import io.restassured.path.json.JsonPath;
import org.junit.Assert;
//Here Map or HashMap is used only for only storing and retrieving values so either can be used 
public class complexJsonMockResponseValidationsHashMap {
	
	@Test
	public void jsonValidations() {
//parse json
	JsonPath js = new JsonPath(payload.CourseDetails());
//Get the list of courses
	List<HashMap<String, Object>> courseList = js.getList("courses");
	System.out.println(courseList);
	for(HashMap<String, Object> course : courseList) {
//Print All course titles and their respective Prices
		String courseTitle = course.get("title").toString();
		String coursePrice = course.get("price").toString();
		System.out.println("Title of the course: " +courseTitle);
		System.out.println("Price of the course: " +coursePrice);
	}
//Print No of courses returned by API
		int noOfCourses = courseList.size();
		System.out.println("Total number of courses: " +noOfCourses);
//Print Purchase Amount
		int purchaseAmt = js.getInt("dashboard.purchaseAmount");
		System.out.println("Purchase amount: " +purchaseAmt);
//Print Title of the second course
		String secondTitle = courseList.get(1).get("title").toString();
		System.out.println("Title of the second course: " +secondTitle);
//Verify if Sum of all Course prices matches with Purchase Amount
		int totalActAmount = 0;
		try {
		for(HashMap<String, Object> course1 : courseList) {
			int coursePrice = (int) course1.get("price") ;
			int noOfCopies = (int) course1.get("copies");
			totalActAmount += coursePrice*noOfCopies;
		}
		System.out.println("Actual total amount of all copies: " +totalActAmount);
		Assert.assertEquals(totalActAmount, purchaseAmt);
		}catch(AssertionError e) {
			System.out.println("Assertion failed: " + e.getMessage());
		}
//When assertion fails further code is not executed
//Print no of copies sold by RPA Course
		String courseToMatch = "RPA";
		boolean found = false;
		for(HashMap<String, Object> course2 : courseList) {
			if(courseToMatch.equals(course2.get("title"))) {
				int noOfCopies1 = (int) course2.get("copies");
				System.out.println("Number of copies sold by RPA course: " +noOfCopies1);
				found = true;
				break;
			}
		}
		// Use the found variable to output a message
        if (!found) {
            System.out.println("RPA course not found.");
        } else {
            System.out.println("RPA course was found.");
        }
	}
}
