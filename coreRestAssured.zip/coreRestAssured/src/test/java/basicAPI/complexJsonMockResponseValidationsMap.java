package basicAPI;

import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import org.junit.Assert;
import files.payload;
import io.restassured.path.json.JsonPath;
//Here Map or HashMap is used only for only storing and retrieving values so either can be used 
public class complexJsonMockResponseValidationsMap {
	
//@Test annotation identifies a method as a test case, which JUnit will execute when running tests. 
//It allows you to define and automate tests, ensuring your code behaves as expected. 
//In API tests, @Test methods can send HTTP requests, validate responses, and verify conditions using assertions. 
//Each @Test method runs independently, providing isolated and reliable test results.
	
	@Test
	public void validations() {
		JsonPath js = new JsonPath(payload.CourseDetails());
//Get list of courses
		List<Map<String, Object>> courseList = js.getList("courses");
		System.out.println("List of courses: " +courseList);
//Print No of courses returned by API
		int numOfCourses = courseList.size();
		System.out.println("Number of courses: " +numOfCourses);
//Print All course titles and their respective Prices
		for(Map<String, Object> course : courseList) {
			String cTitle = course.get("title").toString();
			String cPrice = course.get("price").toString();
			System.out.println("Course title: " +cTitle);
			System.out.println("Course price:" +cPrice);
		}		
//Print Purchase Amount
		int totalAmt = js.getInt("dashboard.purchaseAmount");
		System.out.println("Purchase amount: " +totalAmt);
		
//Print Title of the first course
		String firstCTitle = courseList.get(0).get("title").toString();
		System.out.println("Title of the first course: " +firstCTitle);

//Print Title of the second course
		String secondCTitle = courseList.get(1).get("title").toString();
		System.out.println("Title of the second course: " +secondCTitle);
		
//Verify if Sum of all Course prices matches with Purchase Amount
		int totalActAmt = 0;
		try {
		for(Map<String, Object> course2 : courseList) {
			int cprice = (int) course2.get("price");
			int numOfCopies  = (int) course2.get("copies");
			int sumPrice = cprice*numOfCopies;
			totalActAmt += sumPrice;
			System.out.println("Total price of all courses: " +totalActAmt);
		}
		Assert.assertEquals(totalAmt, totalActAmt);
		}catch(AssertionError e) {
			System.out.println("Assertion Failed: " +e.getMessage());
		}
//Print no of copies sold by RPA Course
		String courseToMatch = "RPA";
		for(Map<String, Object> course1 : courseList) {
			if(courseToMatch.equals(course1.get("title"))){
				int numOfCopies = (int) course1.get("copies");
				System.out.println("No of copies sold by RPA course: " +numOfCopies);
				break;
			}
		}
		}
}
