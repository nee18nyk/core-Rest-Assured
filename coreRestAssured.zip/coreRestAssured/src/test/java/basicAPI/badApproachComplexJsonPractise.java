package basicAPI;

import org.junit.jupiter.api.Test;

import files.payloadone;
import io.restassured.path.json.JsonPath;

//this program is a bad approach of handling nested array. Instead use interfaces using Map 
//so that when more arrays are added in list we don't need to change/ update method code
public class badApproachComplexJsonPractise {
	@Test
	public void Jsonvalidations() {
		JsonPath js = new JsonPath(payloadone.CourseDetailsNestedArray());
//Print No of courses returned by topic webautomation
		int coursescount = js.getInt("courses.webAutomation.size()");
		System.out.println("No of courses returned by webautomation: " +coursescount);
//Print first course title and its respective Price of topic webautomation
		String title = js.getString("courses.webAutomation[0].courseTitle");
		System.out.println("first course title and its respective Price: " +title);
//Print All course titles and their respective Prices of topic webautomation
		for(int i=0; i< coursescount; i++ ) {
			String allTitles = js.getString("courses.webAutomation["+i+"].courseTitle");
			System.out.println("All course titles and their respective Prices: " +allTitles);
		}
//Print Sum of all Courses of topic webautomation
		int sum = 0;
		for (int i=0; i<coursescount; i++) {
			int price = js.getInt("courses.webAutomation["+i+"].price");
			sum = sum + price;
		}
		System.out.println("Sum of all Courses: " +sum);
	}

}
