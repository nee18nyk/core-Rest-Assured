package basicAPI;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.junit.jupiter.api.Test;

public class staticJsonFilePlaceAPI {
	@Test
	public void addPlace() throws IOException {
		//For junit test to return result method should not be static
		//convert content of file to string ->content of file can convert into byte ->Byte data to string
		RestAssured.baseURI = "https://rahulshettyacademy.com";
		String requestBody = new String(Files.readAllBytes(Paths.get("C:\\software\\Postman\\testdata\\AddPlace.json")));
		String response = given().log().all().queryParam("key","qaclick123").header("Content-Type","application/json")
				.body(requestBody)
				.when().post("/maps/api/place/add/json")
				.then().assertThat().log().all().statusCode(200).body("scope", equalTo("APP"))
				.header("Server","Apache/2.4.52 (Ubuntu)").extract().response().asString();
		System.out.println("Post response is: "+response);
	}

}
